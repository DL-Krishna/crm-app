

// function getData() {
//   return [
//     {
//       course: "Spoken English",
//       online : 56,
//       offline: 79
//     },
//     {
//       course: "Public Speaking",
//       online : 13,
//       offline: 34
//     },
//     {
//       course: "Communication Skills ",
//       online : 56,
//       offline: 79
//     },
//     {
//       course: "Soft Skills",
//       online : 34,
//       offline: 5
//     },
//     {
//       course: "Personality Devlopment",
//       online : 13,
//       offline: 33
//     },
//     {
//       course: "Aptitude",
//       online : 69,
//       offline: 12
//     },
//     {
//       course: "IELTS Training",
//       online : 6,
//       offline: 9
//     },
//     {
//       course: "GRE",
//       online : 3,
//       offline: 16
//     },
//     {
//       course: "spoken english",
//       online : 56,
//       offline: 79
//     },
    
    
//   ];
// }

// export default getData